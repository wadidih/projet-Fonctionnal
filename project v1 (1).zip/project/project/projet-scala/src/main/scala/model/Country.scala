package model

case class Country(
  id: Long,
  code: String,
  name: String,
  continent: Option[String],
  wikipediaLink: Option[String],
  keywords: Option[String]
)

object Country {
  def from(csvLine: String): Option[Country] = {
    val fields = csvLine.split(",", -1).map(_.trim)
    if (fields.length >= 6) {
      Some(
        Country(
          id = fields(0).toLongOption.getOrElse(-1L),
          code = fields(1),
          name = fields(2),
          continent = if (fields(3).isEmpty) None else Some(fields(3)),
          wikipediaLink = if (fields(4).isEmpty) None else Some(fields(4)),
          keywords = if (fields(5).isEmpty) None else Some(fields(5))
        )
      ).filter(_.id != -1L)
    } else {
      None
    }
  }
}
