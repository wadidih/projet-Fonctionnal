package model

case class Airport(
  id: Long,
  ident: String,
  airportType: String,
  name: String,
  latitude: Double,
  longitude: Double,
  elevation: Option[Int],
  isoCountry: String
)

object Airport {
  def from(csvLine: String): Option[Airport] = {
    val fields = csvLine.split(",", -1).map(_.trim)
    if (fields.length >= 18) {
      Some(
        Airport(
          id = fields(0).toLongOption.getOrElse(-1L),
          ident = fields(1),
          airportType = fields(2),
          name = fields(3),
          latitude = fields(4).toDoubleOption.getOrElse(0.0),
          longitude = fields(5).toDoubleOption.getOrElse(0.0),
          elevation = fields(6).toIntOption,
          isoCountry = fields(8)
        )
      ).filter(_.id != -1L)
    } else {
      None
    }
  }
}
