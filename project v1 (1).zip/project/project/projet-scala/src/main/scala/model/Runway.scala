package model

case class Runway(
  id: Long,
  airportRef: Long,
  surface: Option[String],
  leIdent: Option[String]
)

object Runway {
  def from(csvLine: String): Option[Runway] = {
    val fields = csvLine.split(",", -1).map(_.trim)
    if (fields.length >= 10) {
      Some(
        Runway(
          id = fields(0).toLongOption.getOrElse(-1L),
          airportRef = fields(1).toLongOption.getOrElse(-1L),
          surface = if (fields(5).isEmpty) None else Some(fields(5)),
          leIdent = if (fields(8).isEmpty) None else Some(fields(8))
        )
      ).filter(r => r.id != -1L && r.airportRef != -1L)
    } else {
      None
    }
  }
}
