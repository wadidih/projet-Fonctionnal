package main
import model.Airport
import model.Runway
import model.Country
import scala.io.Source

object Main {
  def main(args: Array[String]): Unit = {
    println("=== Test parsing Country ===")
    val countryLine = Source.fromFile("data/countries.csv").getLines().drop(1).next()
    val country = Country.from(countryLine)
    println(country)

    println("\n=== Test parsing Airport ===")
    val airportLine = Source.fromFile("data/airports.csv").getLines().drop(1).next()
    val airport = Airport.from(airportLine)
    println(airport)

    println("\n=== Test parsing Runway ===")
    val runwayLine = Source.fromFile("data/runways.csv").getLines().drop(1).next()
    val runway = Runway.from(runwayLine)
    println(runway)
  }
}
